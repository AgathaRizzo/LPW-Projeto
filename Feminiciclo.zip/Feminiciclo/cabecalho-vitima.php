<h1>Vítimas</h1>
<p>Informações necessárias para o cadastro</p>

      <a href="todas-vitimas.php" id="link">Todos(as)</a>
      <a href="cadastro-vitima.php">Cadastrar Vítima</a>


<style>
  html, body{
    box-sizing: border-box;
  }
h1{
  font-size: 50px;
  padding-right:100%
}
p{
  font-size: 18px;
  text-align: left !important;
  margin-top: 3px;
}
#link{
  padding-right: 130px;
}
a {
  color: white;
}
</style>
