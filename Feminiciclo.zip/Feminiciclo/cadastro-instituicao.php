<!DOCTYPE html>
<html>
    <head>
        <title>
            Cadastro de Instituições de Apoio
        </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
      <div id="cabecalho">
        <?php require_once "cabecalho-instituicao.php"; ?>
     </div>
        <form method="POST" action="recebe-cadastro-instituicao.php">
          <div>
            <label for="nomeInstituicao">Nome da Rede de Apoio:</label>
            <input type="text" name="nomeInstituicao" id="nomeInstituicao" placeholder="Ex: Ong SOS Mulheres">
            
            <label for="enderecoInstituicao">Endereço:</label>
            <input type="text" name="enderecoInstituicao" id="enderecoInstituicao" placeholder="Ex: Rua das Flores, 425">
            
            <label for="tipo">Tipo de apoio:</label>
            <input  type="text" name="tipo" id="tipo" placeholder="Ex: Roda de conversa">
         </div>
            <button type="submit" class="botao">Enviar</button>
        </form>
    </body>

<style>
html, body{
 height: 100%;
 width: 100%;
 background-image: linear-gradient(to right, #f7a1a1, #efc2c2, #fbf3f3);
}

.botao{
  width: 10%;
  height: 20%;
  background-color: #fd8ca0;
  border: 1px #f88ea0;
  border-radius: 3px;
  margin: 0 auto;
  color: white;
  display: block;
  padding: 10px;
  margin-top: 20px;
}
p{
  font-size: 18px;
  margin-top: 3px;
}
div{
  padding-left: 44%;
  padding-top:50px;
}
div #cabecalho{
  background-color: red;
  padding-left: 44%;
  margin: 50%;
}
input, textarea{
  font-size:15px;
  display:block;
  width: 250px;
  height: 20px
}

</style>
</html>