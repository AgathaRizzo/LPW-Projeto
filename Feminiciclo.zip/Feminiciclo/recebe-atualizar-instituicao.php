<!DOCTYPE html>
<html>

<head>
  <title>Cadastro Profissional</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
  <script src="scriptCadastro.js"></script>
</head>
  
<body>
<?php
    require_once "Instituicao.class.php";
    
    $nomeInstituicao = $_POST["nomeInstituicao"];
    $enderecoInstituicao = $_POST["enderecoInstituicao"];
    $tipo = $_POST["tipo"];

    $obj = new Instituicao($nomeInstituicao, $enderecoInstituicao, $tipo);
    $obj->atualizaInstituicao();
    header("Location: todas-instituicoes.php");//redireciona
?>


</body>
  </html>