<!DOCTYPE html>
<html>
    <head>
        <title>
            Atualização dos dados de profissionais</title>
        <style>
            input, textarea{
                display: block;
            }
        </style>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
        <script src="scriptCadastro.js"></script>
    </head>
    <body>
    <div id="cabecalho">
        <?php require_once "cabecalho-profissional.php";?>
        </div>
        <?php
            $nome = $_GET["nome"];
            $cpf = $_GET["cpf"];
            $formacao = $_GET["formacao"];
            $horario = $_GET["horario"];
            $forma = $_GET["forma"];
        ?>
    <div>
        <form method="POST" action="recebe-atualizar-profissional.php">
        <label for="nome">Nome:</label>
            <input type="text" name="nome" id="nome" value="<?php echo $nome;?>" readonly>
            
            <label for="cpf">CPF:</label>
            <input type="text" name="cpf" id="cpf" value="<?php echo $cpf;?>">
            
            <label for="formacao">Area de formação acadêmica:</label>
            <input  type="text" name="formacao" id="formacao" value="<?php echo $formacao;?>">

            <label for="horario">Horario de atendimento:</label>
            <input type="text" name="horario" id="horario" value="<?php echo $horario;?>">
 
            <label for="forma">Forma de atendimento:</label>
              <input type="text" name="forma" id="forma" cols="30" rows="5" value="<?php echo $forma;?>">       
    </div>
            <button type="submit" class="botao">Reenviar</button> 
        </form>
    </body>

    <style>
html, body{
 height: 100%;
 width: 100%;
 background-image: linear-gradient(to right, #f7a1a1, #efc2c2, #fbf3f3);
}

.botao{
  width: 120px;
  height: 40px;
  background-color: #fd8ca0;
  border: 1px #f88ea0;
  border-radius: 3px;
  margin: 0 auto;
  color: white;
  display: block;
  padding: 10px;
  margin-top: 20px;
}
p{
  font-size: 18px;
  margin-top: 3px;
}
div{
  padding-left: 44%;
}
div #cabecalho{
  background-color: red;
  padding-left: 44%;
  margin: 50%;
}
input, textarea{
  font-size:15px;
  display:block;
  width: 250px;
  height: 20px
}

</style>
</html>