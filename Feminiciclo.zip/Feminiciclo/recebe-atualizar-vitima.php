<!DOCTYPE html>
<html>

<head>
  <title>Cadastro Vitima</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
  <script src="scriptCadastro.js"></script>
</head>
  
<body>
<?php
    require_once "Vitima.class.php";
    
    $nome = $_POST["nome"];
    $sobrenome = $_POST["sobrenome"];
    $idade = $_POST["idade"];
    $rg = $_POST["rg"];
    $boletim = $_POST["boletim"];

    $obj = new Vitima($nome, $sobrenome, $idade, $rg, $boletim);
    $obj->atualizaVitima();
    header("Location: todas-vitimas.php");//redireciona
?>


</body>
  </html>