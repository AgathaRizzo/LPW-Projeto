<?php
    $nome = $_GET["nome"];
    require_once "Vitima.class.php";
    $objeto = new Vitima();
    $objeto->excluirVitima($nome);
    header("Location: todas-vitimas.php");