<!DOCTYPE html>
<html>

<head>
  <title>Cadastro Instituicao</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
  <script src="scriptCadastro.js"></script>
</head>
  
<body>
  <div id="cabecalho">
<?php
    require_once "cabecalho-profissional.php";
    require_once("Profissional.class.php");

    $nome = $_POST["nome"];
    $cpf = $_POST["cpf"];
    $formacao = $_POST["formacao"];
    $horario = $_POST["horario"];
    $forma = $_POST["forma"];

    $objetoProfissional = new Profissional($nome, $cpf, $formacao, $horario, $forma);
    $objetoProfissional->exibirDados();
    $objetoProfissional->inserirProfissional();

?>
</div>
  <button type="button" class="botao"><a href="principal.html">Prosseguir</a></button>
  
  <style>

html, body{
 height: 100%;
 width: 100%;
 background-image: linear-gradient(to right, #f7a1a1, #efc2c2, #fbf3f3);
 font-size: 22px;
}

  .botao{
  width: 120px;
  height: 40px;
  background-color: #fd8ca0;
  border: 1px #f88ea0;
  border-radius: 3px;
  margin: 0 auto;
  color: white;
  display: block;
  padding: 10px;
  margin-top: 20px;
}
p{
  font-size: 18px;
  margin-top: 3px;
}
div{
  padding-left: 40%;
  padding-top: 12%;
}
div #cabecalho{
  background-color: red;
  padding-left: 44%;
  margin: 50%;
}
input, textarea{
  font-size:15px;
  display:block;
  width: 250px;
  height: 20px
}


  </style>
    </body>
  </html>