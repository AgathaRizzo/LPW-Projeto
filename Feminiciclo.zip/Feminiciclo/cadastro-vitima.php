<!DOCTYPE html>
<html>
    <head>
        <title>
            Cadastro de Vítimas
        </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
        <script src="scriptCadastro.js"></script>
    </head>
    <body>
      <div id="cabecalho">
        <?php require_once "cabecalho-vitima.php"; ?>
     </div>
        <form method="POST" action="recebe-cadastro-vitima.php">
          <div>
            <label for="nome">Nome:</label>
            <input type="text" name="nome" id="nome" placeholder="Ex: Elen">
            
            <label for="sobrenome">Sobrenome:</label>
            <input type="text" name="sobrenome" id="sobrenome" placeholder="Ex: Silva">
            
            <label for="idade">Idade:</label>
            <input  type="number" name="idade" id="idade" cols="30" rows="5" placeholder="Ex: 20 anos">

            <label for="rg">RG:</label>
            <input type="text" name="rg" id="rg" placeholder="Ex: XX.XXX.XXX.X">
 
         
            <label for="boletim">Boletim:</label>
              <input type="text" name="boletim" id="boletim" cols="30" rows="5" placeholder="Foi feito B.O ? (Sim) ou (Não)"checked>
         </div>
            <button type="submit" class="botao">Enviar</button>
        </form>
    </body>

<style>
html, body{
 height: 100%;
 width: 100%;
 background-image: linear-gradient(to right, #f7a1a1, #efc2c2, #fbf3f3);
}

.botao{
  width: 10%;
  height: 20%;
  background-color: #fd8ca0;
  border: 1px #f88ea0;
  border-radius: 3px;
  margin: 0 auto;
  color: white;
  display: block;
  padding: 10px;
  margin-top: 20px;
}
p{
  font-size: 18px;
  margin-top: 3px;
}
div{
  padding-left: 44%;
  padding-top:50px;
}
div #cabecalho{
  background-color: red;
  padding-left: 44%;
  margin: 50%;
}
input, textarea{
  font-size:15px;
  display:block;
  width: 250px;
  height: 20px
}

</style>
</html>