<?php
    require_once "Conexao.class.php";

    class Instituicao{
        private $nomeInstituicao;
        private $enderecoInstituicao;
        private $tipo;
        
        public function exibirDados(){
            echo "<br />";
            echo "Nome da Instituição: ". $this->nomeInstituicao;
            echo "<br /> ";
            echo "Endereço: ". $this->enderecoInstituicao;
            echo "<br />";
            echo "Tipo de apoio: ". $this->tipo;
              
        }

        public function __construct($nomeInstituicao="", $enderecoInstituicao="", $tipo=""){
            $this->nomeInstituicao = $nomeInstituicao;
            $this->enderecoInstituicao = $enderecoInstituicao;
            $this->tipo = $tipo;
        }

        public function setNomeInstituicao($nomeInstituicao){
            $this->NomeInstituicao = $nomeInstituicao;
        }
        public function getNomeInstituicao(){
            return $this->NomeInstituicao;
        }
        public function setEnderecoInstituicao($enderecoInstituicao){
            $this->EnderecoInstituicao = $enderecoInstituicao;
        }
        public function getEnderecoInstituicao(){
            return $this->enderecoInstituicao;
        }
        public function setTipo($tipo){
            $this->tipo = $tipo;
        }
        public function getTipo(){
            return $this->tipo;
        }

        public function inserirInstituicao()
        {
            $cn = new Conexao();
            $conexaoBanco = $cn->getInstance();

            $stmt = $conexaoBanco->prepare("INSERT INTO instituicao VALUES (:nomeInstituicao, :enderecoInstituicao, :tipo)");
            $stmt->bindParam(':nomeInstituicao', $this->nomeInstituicao);
            $stmt->bindParam(':enderecoInstituicao', $this->enderecoInstituicao);
            $stmt->bindParam(':tipo', $this->tipo);

            $resultado = $stmt->execute();

            if(!$resultado){
                echo "<br>";
                echo "Erro, não foi possível inserir a instituição";
                exit;
            }
            echo "<br>";
            echo "<br>";
            echo "Cadastro realizado com sucesso!";
        }
        
        public function buscarTodasInstituicoes(){
            $cn = new Conexao();
            $conexaoBanco = $cn->getInstance();
            
            $stmt = $conexaoBanco->prepare("SELECT * 
                                        FROM instituicao");

            $stmt->execute();

            $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return $resultado;

        }

        public function atualizaInstituicao(){
            $cn = new Conexao();
            $conexaoBanco = $cn->getInstance();

            $stmt = $conexaoBanco->prepare("UPDATE instituicao SET
                                            enderecoInstituicao = :novoEnderecoInstituicao,
                                            tipo = :novoTipo
                                            WHERE nomeInstituicao = :nomeInstituicao");
            $stmt->bindParam(":novoEnderecoInstituicao",$this->enderecoInstituicao);
            $stmt->bindParam(":novoTipo", $this->tipo);
            $stmt->bindParam(":nomeInstituicao", $this->nomeInstituicao);

            $resultado = $stmt->execute();

            if(!$resultado){
                echo "Não foi possível atualizar as instituições";
                exit;
            }
            echo "Lista de Instituições atualizada com sucesso";
        }

        function excluirInstituicao($nomeInstituicao){
            $cn = new Conexao();
            $conexaoBanco = $cn->getInstance();

            $stmt=$conexaoBanco->prepare("DELETE FROM instituicao WHERE nomeInstituicao = :nomeInstituicao");
            $stmt->bindParam(":nomeInstituicao", $nomeInstituicao);
            $resultado = $stmt->execute();
            if(!$resultado){
                echo "Não foi possível excluir";
                exit;
            }
            echo "Instituição excluida com sucesso";

        }
    }
    