<?php
 class Login {
     private $email;
     private $senha;

    public function dadosLogin(){
        echo "<br />";
        echo "email: ". $this->email;
        echo "<br />";
        echo "Senha: ". $this->senha;
    } 
    public function __construct($email, $senha){
        $this->email = $email;
        $this->senha = $senha;
        echo "<br />Login concluído com sucesso com sucesso!";
        echo "<br />";
    }
    public function setEmail($email){
        $this->email = $email;
    }
    public function getEmail(){
        return $this->email;
    }
    public function setSenha($senha){
        $this->senha = $senha;
    }
    public function getSenha(){
        return $this->senha;
    }

    public function inserirLogin()
        {
            //Conectar com o BD
            $conexao = mysqli_connect("localhost","root","", "feminiciclo");
            
            //Verificando a conexão
            if(!$conexao){
                die("Falha na conexão com o BD");
            }
            echo"<br />";
            echo"<br />";
            echo "Login realizado com sucesso";

            //Criando a string de inserção (código SQL)
            $sql = "INSERT INTO login VALUES ('$this->email', '$this->senha')";
           
            //Executando a inserção e verificando sucesso
            if(mysqli_query($conexao, $sql)){
                echo"<br />";
                echo "Conectado com o banco";
                
            }else{
                echo "Erro: ".mysqli_error($conexao);
            }
            mysqli_close($conexao);
        }
 }