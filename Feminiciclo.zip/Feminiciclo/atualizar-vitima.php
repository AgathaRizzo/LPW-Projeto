<!DOCTYPE html>
<html>
    <head>
        <title>
            Atualização de vítima</title>
        <style>
            input, textarea{
                display: block;
            }
        </style>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
        <script src="scriptCadastro.js"></script>
    </head>
    <body>
    <div id="cabecalho">
        <?php require_once "cabecalho-vitima.php";?>
        </div>
        <?php
            $nome = $_GET["nome"];
            $sobrenome = $_GET["sobrenome"];
            $idade = $_GET["idade"];
            $rg = $_GET["rg"];
            $boletim = $_GET["boletim"];
        ?>
    <div>
        <form method="POST" action="recebe-atualizar-vitima.php">
            <label for="nome">Nome:</label>
            <input type="text" name="nome" id="nome" value="<?php echo $nome;?>" readonly>
            
            <label for="sobrenome">Sobrenome:</label>
            <input type="text" name="sobrenome" id="sobrenome" value="<?php echo $sobrenome;?>">
            
            <label for="idade">Idade:</label>
            <input type="number" name="idade" id="idade" cols="30" rows="5" value="<?php echo $idade; ?>">

            <label for="rg">RG:</label>
            <input name="rg" id="rg" cols="30" rows="5" value="<?php echo $rg; ?>">

            <label for="boletim">Boletim:</label>
            <input type="text" name="boletim" id="boletim"  cols="30" rows="5"  value="<?php echo $boletim; ?>">
    </div>
            <button type="submit" class="botao">Reenviar</button> 
        </form>
    </body>

    <style>
html, body{
 height: 100%;
 width: 100%;
 background-image: linear-gradient(to right, #f7a1a1, #efc2c2, #fbf3f3);
}

.botao{
  width: 120px;
  height: 40px;
  background-color: #fd8ca0;
  border: 1px #f88ea0;
  border-radius: 3px;
  margin: 0 auto;
  color: white;
  display: block;
  padding: 10px;
  margin-top: 20px;
}
p{
  font-size: 18px;
  margin-top: 3px;
}
div{
  padding-left: 44%;
}
div #cabecalho{
  background-color: red;
  padding-left: 44%;
  margin: 50%;
}
input, textarea{
  font-size:15px;
  display:block;
  width: 250px;
  height: 20px
}

</style>
</html>