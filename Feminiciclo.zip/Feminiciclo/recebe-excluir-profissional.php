<?php
    $nome = $_GET["nome"];
    require_once "Profissional.class.php";
    $objeto = new Profissional();
    $objeto->excluirProfissional($nome);
    header("Location: todos-profissionais.php");