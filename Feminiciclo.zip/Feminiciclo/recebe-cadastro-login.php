<!DOCTYPE html>
<html>

<head>
  <title>Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
  <script src="scriptCadastro.js"></script>
</head>

  <body>

    <section class="menu-cadastro-profissional">
      <section class="navegacao">
        <h1>Login</h1>
        <p>Informações do(a) pessoa cadastrado(a):</p>
      </section>

<?php
    require_once("cadastro-login.php");

    $email = $_POST["email"];
    $senha = $_POST["senha"];

    $objetoLogin = new Login($email, $senha);
    $objetoLogin->dadosLogin();
    $objetoLogin->inserirLogin();
 ?>

</body>
</html>