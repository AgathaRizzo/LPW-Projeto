<!DOCTYPE html>
    <html>
        <head>
            <title>Todas vitimas</title>
            <script>
                function confirmarExclusao(nome){
                    var resp = window.confirm("tem certeza que deseja excluir "+nome+"?");
                    if(resp){
                    window.location.href="recebe-excluir-vitimas.php?nome="+nome;
                }
                }
            </script>

            <style>
                body{
                    align-items: center;
                }
              table{
                text-align: center;
                display: block;
                margin: 0 auto;
              }
        

            </style>

            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width">
            <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
            <script src="scriptCadastro.js"></script>
        </head>
        <body>
        <div id="cabecalho">
            <?php require_once "cabecalho-vitima.php"; ?>
        </div>
        <div>
            <h2>Todos os cadastros</h2>
            <table>
                <tr>
                       <th>Nome</th>
                       <th>Sobrenome</th>
                       <th>Idade</th>
                       <th>RG</th>
                       <th>Boletim</th>
                       <th>Ações</th>
                </tr>
                <?php
                    require_once "Vitima.class.php";
                    $objVitima = new Vitima();
                    $vitimas = $objVitima->buscarTodasVitimas();
                    
                    foreach($vitimas AS $dc){
                        echo "<tr>";
                        echo "<td>".$dc["nome"]."</td>";
                        echo "<td>".$dc["sobrenome"]."</td>";
                        echo "<td>".$dc["idade"]."</td>";
                        echo "<td>".$dc["rg"]."</td>";
                        echo "<td>".$dc["boletim"]."</td>";
                        echo "<td><a href='atualizar-vitima.php?nome={$dc["nome"]}&sobrenome={$dc["sobrenome"]}&idade={$dc["idade"]}&rg={$dc["rg"]}&boletim={$dc["boletim"]}'>
                        Editar</a> |  <a href='javascript:func()' onclick='confirmarExclusao(\"{$dc["nome"]}\")'>Excluir</a></td>";
                        echo "</tr>";
                    }
                ?>
            </table>
            </div>
            <button type="button" class="botao"><a href="principal.html">Prosseguir</a></button>
        </body>

<style>
html, body{
 height: 100%;
 width: 100%;
 background-image: linear-gradient(to right, #f7a1a1, #efc2c2, #fbf3f3);
}

.botao{
  width: 120;
  height: 30;
  background-color: #fd8ca0;
  border: 1px #f88ea0;
  border-radius: 3px;
  margin: 0 auto;
  color: white;
  display: block;
  padding: 10px;
  margin-top: 20px;
}
p{
  font-size: 18px;
  margin-top: 3px;
}
div{
  padding-left: 25%;
  margin-bottom: 20px;
  padding-top: 50px;
}
div #cabecalho{
  background-color: red;
  padding-left: 44%;
  margin: 50%;
}
input, textarea{
  font-size:15px;
  display:block;
  width: 250px;
  height: 20px
}

</style>
</html>