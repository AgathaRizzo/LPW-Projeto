<?php
    $nomeInstituicao = $_GET["nomeInstituicao"];
    require_once "Instituicao.class.php";
    $objeto = new Instituicao();
    $objeto->excluirInstituicao($nomeInstituicao);
    header("Location: todas-instituicoes.php");