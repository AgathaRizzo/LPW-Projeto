<!DOCTYPE html>
<html>
    <head>
        <title>
            Cadastro de Profissionais
        </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
      <div id="cabecalho">
        <?php require_once "cabecalho-profissional.php"; ?>
     </div>
        <form method="POST" action="recebe-cadastro-profissional.php">
          <div>
            <label for="nome">Nome:</label>
            <input type="text" name="nome" id="nome" placeholder="Ex: Luciano">
            
            <label for="cpf">CPF:</label>
            <input type="text" name="cpf" id="cpf" placeholder="Ex: XXX-XXX-XXX-XX">
            
            <label for="formacao">Area de formação acadêmica:</label>
            <input  type="text" name="formacao" id="formacao" placeholder="Ex: Psicologia">

            <label for="horario">Horario de atendimento:</label>
            <input type="text" name="horario" id="horario" placeholder="Ex: 14:00 as 17:00hrs">
 
            <label for="forma">Forma de atendimento:</label>
              <input type="text" name="forma" id="forma" placeholder="Ex: Online ou Presencial"checked>
         </div>
            <button type="submit" class="botao">Enviar</button>
        </form>
    </body>

<style>
html, body{
 height: 100%;
 width: 100%;
 background-image: linear-gradient(to right, #f7a1a1, #efc2c2, #fbf3f3);
}

.botao{
  width: 10%;
  height: 20%;
  background-color: #fd8ca0;
  border: 1px #f88ea0;
  border-radius: 3px;
  margin: 0 auto;
  color: white;
  display: block;
  padding: 10px;
  margin-top: 20px;
}
p{
  font-size: 18px;
  margin-top: 3px;
}
div{
  padding-left: 44%;
  padding-top:50px;
}
div #cabecalho{
  background-color: red;
  padding-left: 44%;
  margin: 50%;
}
input, textarea{
  font-size:15px;
  display:block;
  width: 250px;
  height: 20px
}

</style>
</html>