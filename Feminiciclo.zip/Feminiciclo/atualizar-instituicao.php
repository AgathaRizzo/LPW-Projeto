<!DOCTYPE html>
<html>
    <head>
        <title>
            Atualização de informações das redes de Apoio</title>
        <style>
            input, textarea{
                display: block;
            }
        </style>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
        <script src="scriptCadastro.js"></script>
    </head>
    <body>
    <div id="cabecalho">
        <?php require_once "cabecalho-instituicao.php";?>
        </div>
        <?php
            $nomeInstituicao = $_GET["nomeInstituicao"];
            $enderecoInstituicao = $_GET["enderecoInstituicao"];
            $tipo = $_GET["tipo"];
        ?>
    <div>
        <form method="POST" action="recebe-atualizar-instituicao.php">
        <label for="nomeInstituicao">Nome da Rede de Apoio:</label>
            <input type="text" name="nomeInstituicao" id="nomeInstituicao" value="<?php echo $nomeInstituicao;?>" readonly>
            
            <label for="enderecoInstituicao">Endereço:</label>
            <input type="text" name="enderecoInstituicao" id="enderecoInstituicao" value="<?php echo $enderecoInstituicao;?>">
            
            <label for="tipo">Tipo de apoio:</label>
            <input  type="text" name="tipo" id="tipo" value="<?php echo $tipo;?>">       
    </div>
            <button type="submit" class="botao">Reenviar</button> 
        </form>
    </body>

    <style>
html, body{
 height: 100%;
 width: 100%;
 background-image: linear-gradient(to right, #f7a1a1, #efc2c2, #fbf3f3);
}

.botao{
  width: 120px;
  height: 40px;
  background-color: #fd8ca0;
  border: 1px #f88ea0;
  border-radius: 3px;
  margin: 0 auto;
  color: white;
  display: block;
  padding: 10px;
  margin-top: 20px;
}
p{
  font-size: 18px;
  margin-top: 3px;
}
div{
  padding-left: 44%;
}
div #cabecalho{
  background-color: red;
  padding-left: 44%;
  margin: 50%;
}
input, textarea{
  font-size:15px;
  display:block;
  width: 250px;
  height: 20px
}

</style>
</html>