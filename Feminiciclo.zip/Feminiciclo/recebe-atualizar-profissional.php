<!DOCTYPE html>
<html>

<head>
  <title>Cadastro Profissional</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
  <script src="scriptCadastro.js"></script>
</head>
  
<body>
<?php
    require_once "Profissional.class.php";
    
    $nome = $_POST["nome"];
    $cpf = $_POST["cpf"];
    $formacao = $_POST["formacao"];
    $horario = $_POST["horario"];
    $forma = $_POST["forma"];

    $obj = new Profissional($nome, $cpf, $formacao, $horario, $forma);
    $obj->atualizaProfissional();
    header("Location: todos-profissionais.php");//redireciona
?>


</body>
  </html>