<?php
    require_once "Conexao.class.php";

    class Vitima{
        private $nome;
        private $sobrenome;
        private $idade;
        private $rg;
        private $boletim;

        public function exibirDados(){
            echo "<br />";
            echo "Nome: ". $this->nome;
            echo "<br /> ";
            echo "Sobrenome: ". $this->sobrenome;
            echo "<br />";
            echo "Idade: ". $this->idade;
            echo "<br />";
            echo "RG: ". $this->rg;
            echo "<br />";
            echo "Boletim de Ocorrência (sim ou não): ". $this->boletim;  
        }

        public function __construct($nome="", $sobrenome="", $idade="",$rg="", $boletim=""){
            $this->nome = $nome;
            $this->sobrenome = $sobrenome;
            $this->idade = $idade;
            $this->rg = $rg;
            $this->boletim = $boletim;
        }

        public function setNome($nome){
            $this->nome = $nome;
        }
        public function getNome(){
            return $this->nome;
        }
        public function setSobrenome($sobrenome){
            $this->sobrenome = $sobrenome;
        }
        public function getSobrenome(){
            return $this->sobrenome;
        }
        public function setIdade($idade){
            $this->idade = $idade;
        }
        public function getIdade(){
            return $this->idade;
        }
        public function setRG($rg){
            $this->rg = $rg;
        }
        public function getRG(){
            return $this->rg;
        }
        public function setBoletim($boletim){
            $this->boletim = $boletim;
        }
        public function getBoletim(){
            return $this->boletim;
        }

        public function inserirVitima()
        {
            $cn = new Conexao();
            $conexaoBanco = $cn->getInstance();

            $stmt = $conexaoBanco->prepare("INSERT INTO vitima VALUES (:nome, :sobrenome, :idade, :rg, :boletim)");
            $stmt->bindParam(':nome', $this->nome);
            $stmt->bindParam(':sobrenome', $this->sobrenome);
            $stmt->bindParam(':idade', $this->idade);
            $stmt->bindParam(':rg', $this->rg);
            $stmt->bindParam(':boletim', $this->boletim);

            $resultado = $stmt->execute();

            if(!$resultado){
                echo "Erro, não foi possível inserir a vitima";
                exit;
            }
            echo "<br>";
            echo "<br>";
            echo "Cadastro realizado com sucesso!";
        }
        
        public function buscarTodasVitimas(){
            $cn = new Conexao();
            $conexaoBanco = $cn->getInstance();
            
            $stmt = $conexaoBanco->prepare("SELECT * 
                                        FROM vitima");

            $stmt->execute();

            $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return $resultado;

        }

        public function atualizaVitima(){
            $cn = new Conexao();
            $conexaoBanco = $cn->getInstance();

            $stmt = $conexaoBanco->prepare("UPDATE vitima SET
                                            sobrenome = :novoSobrenome,
                                            idade = :novaIdade,
                                            rg = :novoRG,
                                            boletim = :novoBoletim
                                            WHERE nome = :nome");
            $stmt->bindParam(":novoSobrenome",$this->sobrenome);
            $stmt->bindParam(":novaIdade", $this->idade);
            $stmt->bindParam(":novoRG", $this->rg);
            $stmt->bindParam(":novoBoletim", $this->boletim);
            $stmt->bindParam(":nome", $this->nome);

            $resultado = $stmt->execute();

            if(!$resultado){
                echo "Não foi possível atualizar as vítimas";
                exit;
            }
            echo "Lista de Vítimas atualizadas com sucesso";
        }

        function excluirVitima($nome){
            $cn = new Conexao();
            $conexaoBanco = $cn->getInstance();

            $stmt=$conexaoBanco->prepare("DELETE FROM vitima WHERE nome = :nome");
            $stmt->bindParam(":nome", $nome);
            $resultado = $stmt->execute();
            if(!$resultado){
                echo "Não foi possível excluir";
                exit;
            }
            echo "Vitima excluida com sucesso";

        }
    }
    