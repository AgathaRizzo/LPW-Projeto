<?php
    require_once "Conexao.class.php";

    class Profissional{
        private $nome;
        private $cpf;
        private $formacao;
        private $horario;
        private $forma;
        

        public function exibirDados(){
            echo "<br />";
            echo "Nome: ". $this->nome;
            echo "<br /> ";
            echo "CPF: ". $this->cpf;
            echo "<br />";
            echo "Area de formação: ". $this->formacao;
            echo "<br />";
            echo "Horário de atendimento: ". $this->horario;
            echo "<br />";
            echo "Forma de atendimento: ". $this->forma;
              
        }

        public function __construct($nome="", $cpf="", $formacao="",$horario="", $forma=""){
            $this->nome = $nome;
            $this->cpf = $cpf;
            $this->formacao = $formacao;
            $this->horario = $horario;
            $this->forma = $forma;
        }

        public function setNome($nome){
            $this->nome = $nome;
        }
        public function getNome(){
            return $this->nome;
        }
        public function setCPF($cpf){
            $this->cpf = $cpf;
        }
        public function getCPF(){
            return $this->cpf;
        }
        public function setFormacao($formacao){
            $this->formacao = $formacao;
        }
        public function getFormacao(){
            return $this->formacao;
        }
        public function setHorario($horario){
            $this->horario = $horario;
        }
        public function getHorario(){
            return $this->horario;
        }
        public function setForma($forma){
            $this->forma = $forma;
        }
        public function getForma(){
            return $this->forma;
        }

        public function inserirProfissional()
        {
            $cn = new Conexao();
            $conexaoBanco = $cn->getInstance();

            $stmt = $conexaoBanco->prepare("INSERT INTO profissional VALUES (:nome, :cpf, :formacao, :horario, :forma)");
            $stmt->bindParam(':nome', $this->nome);
            $stmt->bindParam(':cpf', $this->cpf);
            $stmt->bindParam(':formacao', $this->formacao);
            $stmt->bindParam(':horario', $this->horario);
            $stmt->bindParam(':forma', $this->forma);

            $resultado = $stmt->execute();

            if(!$resultado){
                echo "<br>";
                echo "Erro, não foi possível inserir o(a) profissional";
                exit;
            }
            echo "<br>";
            echo "<br>";
            echo "Cadastro realizado com sucesso!";
        }
        
        public function buscarTodosProfissionais(){
            $cn = new Conexao();
            $conexaoBanco = $cn->getInstance();
            
            $stmt = $conexaoBanco->prepare("SELECT * 
                                        FROM profissional");

            $stmt->execute();

            $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return $resultado;

        }

        public function atualizaProfissional(){
            $cn = new Conexao();
            $conexaoBanco = $cn->getInstance();

            $stmt = $conexaoBanco->prepare("UPDATE profissional SET
                                            cpf = :novoCPF,
                                            formacao = :novaFormacao,
                                            horario = :novoHorario,
                                            forma = :novaForma
                                            WHERE nome = :nome");
            $stmt->bindParam(":novoCPF",$this->cpf);
            $stmt->bindParam(":novaFormacao", $this->formacao);
            $stmt->bindParam(":novoHorario", $this->horario);
            $stmt->bindParam(":novaForma", $this->forma);
            $stmt->bindParam(":nome", $this->nome);

            $resultado = $stmt->execute();

            if(!$resultado){
                echo "Não foi possível atualizar os(as) profissionais";
                exit;
            }
            echo "Lista de Profissionais atualizada com sucesso";
        }

        function excluirProfissional($nome){
            $cn = new Conexao();
            $conexaoBanco = $cn->getInstance();

            $stmt=$conexaoBanco->prepare("DELETE FROM profissional WHERE nome = :nome");
            $stmt->bindParam(":nome", $nome);
            $resultado = $stmt->execute();
            if(!$resultado){
                echo "Não foi possível excluir";
                exit;
            }
            echo "Profissional excluido(a) com sucesso";

        }
    }
    