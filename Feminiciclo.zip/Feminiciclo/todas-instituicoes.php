<!DOCTYPE html>
    <html>
        <head>
            <title>Todas as instituições</title>
            <script>
                function confirmarExclusao(nomeInstituicao){
                    var resp = window.confirm("tem certeza que deseja excluir "+nomeInstituicao+"?");
                    if(resp){
                    window.location.href="recebe-excluir-instituicao.php?nome="+nomeInstituicao;
                }
                }
            </script>

            <style>
                body{
                    align-items: center;
                }
              table{
                text-align: center;
                display: block;
                margin: 0 auto;
              }
        

            </style>

            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width">
            <link href="styleCadastro.css" rel="stylesheet" type="text/css" />
            <script src="scriptCadastro.js"></script>
        </head>
        <body>
        <div id="cabecalho">
            <?php require_once "cabecalho-instituicao.php"; ?>
        </div>
        <div>
            <h2>Todas as instituições cadastradas</h2>
            <table>
                <tr>
                       <th>Nome</th>
                       <th>Endereço</th>
                       <th>Tipo Apoio</th>
                       <th>Ações</th>
                </tr>
                <?php
                    require_once "Instituicao.class.php";
                    $objInstituicao = new Instituicao();
                    $instituicoes = $objInstituicao->buscarTodasInstituicoes();
                    
                    foreach($instituicoes AS $dc){
                        echo "<tr>";
                        echo "<td>".$dc["nomeInstituicao"]."</td>";
                        echo "<td>".$dc["enderecoInstituicao"]."</td>";
                        echo "<td>".$dc["tipo"]."</td>";
                        echo "<td><a href='atualizar-instituicao.php?nomeInstituicao={$dc["nomeInstituicao"]}&enderecoInstituicao={$dc["enderecoInstituicao"]}&tipo={$dc["tipo"]}'>
                        Editar</a> |  <a href='javascript:func()' onclick='confirmarExclusao(\"{$dc["nomeInstituicao"]}\")'>Excluir</a></td>";
                        echo "</tr>";
                    }
                ?>
            </table>
            </div>
            <button type="button" class="botao"><a href="principal.html">Prosseguir</a></button>
        </body>

<style>
html, body{
 height: 100%;
 width: 100%;
 background-image: linear-gradient(to right, #f7a1a1, #efc2c2, #fbf3f3);
}

.botao{
  width: 120;
  height: 30;
  background-color: #fd8ca0;
  border: 1px #f88ea0;
  border-radius: 3px;
  margin: 0 auto;
  color: white;
  display: block;
  padding: 10px;
  margin-top: 20px;
}
p{
  font-size: 18px;
  margin-top: 3px;
}
div{
  padding-left: 25%;
  margin-bottom: 20px;
  padding-top: 50px;
}
div #cabecalho{
  background-color: red;
  padding-left: 40%;
  margin: 50%;
}
input, textarea{
  font-size:15px;
  display:block;
  width: 250px;
  height: 20px
}

</style>
</html>